# SpamSms
Spam sms (UPDATE)

# How To Use
$ pkg update && pkg upgrade<br>
$ pkg install python<br>
$ pkg install git<br>
$ git clone https://github.com/KANG-NEWBIE/SpamSms<br>
$ pip install requests mechanize bs4<br>
$ cd SpamSms<br>
$ python main.py

# NOTE
selalu ingat kata pepatah saya yang berbunyi "BANGSAD KAO" sekian dan terima gaji

